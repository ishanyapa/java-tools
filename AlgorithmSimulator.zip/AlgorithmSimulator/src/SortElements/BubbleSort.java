/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SortElements;

import RootElement.SessionHandler;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

/**
 *
 * @author Ishan
 */
public class BubbleSort implements Runnable {
    int [] intArray;
    JButton [] btnArray;
    Thread t;
    JPanel jp;
    volatile boolean finished = false;
    JTextField jtf;
    JTextField jtf2;
    JButton sortBtn;
    public BubbleSort(int [] arr, JButton [] btn, JPanel jp, JTextField txt, JTextField txt2,JButton sbtn){
        this.intArray=arr;
        this.btnArray=btn;
        this.jp=jp;
        this.jtf=txt;
        this.jtf2=txt2;
        this.sortBtn = sbtn;
        SessionHandler.setCurrentStatus("pending");
        finished = false;  
    }
    
    public void start(){
        if(t==null){
            t = new Thread(this);
            t.start();
        }
    }
    
    public void stopThread(){
        finished=true;
    }
    
    public void run(){
        sortBtn.setEnabled(finished);
        while(!finished){
            int temp;
            JButton tempBtn=null;
            
            for(int i=0;i<intArray.length-1;i++){
                jtf.setText(String.valueOf(i));
                synchronized(t){
                    slowTimer.start();
                    try {
                        t.wait();
                    } catch (Exception e) {
                    }
                }
                for(int j=1; j<intArray.length-i; j++){
                    
                    synchronized(t){
                        jtf2.setText(String.valueOf(j));
                        btnArray[j-1].setBackground(Color.blue);
                        btnArray[j].setBackground(Color.blue);
                        slowTimer.start();
                        try {
                            t.wait();
                        } catch (Exception e) {
                        }
                    }
                    
                    if(intArray[j-1]>intArray[j]){
                        temp = intArray[j-1];
                        intArray[j-1]=intArray[j];
                        intArray[j]=temp;
                        
                        SwapBubbleNodes swb = new SwapBubbleNodes(btnArray[j-1],btnArray[j],this, jp);
                        synchronized(this){
                            swb.start();
                            try {
                                System.out.println("waiting...");
                                this.wait();
                            } catch (Exception e) {
                            }
                            System.out.println("Main thread is back");
                            tempBtn = btnArray[j-1];
                            btnArray[j-1]=btnArray[j];
                            btnArray[j]=tempBtn;
                        }
                    }
                    btnArray[j-1].setBackground(Color.white);
                    btnArray[j].setBackground(Color.red);
                    
                }
            }
            for(int k=0; k<btnArray.length; k++)
                btnArray[k].setBackground(Color.red);
            finished=true;
            sortBtn.setEnabled(finished);
            SessionHandler.setCurrentStatus("sorted");
        }
        System.out.println("Thread Stopped");
    }
    
    Timer slowTimer = new Timer(1000,new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
           synchronized(t){
               t.notify();
           }
        }
    });
    
}


class SwapBubbleNodes implements Runnable{
    private BubbleSort bs=null;
    JButton buttonLeft, buttonRigt;
    int y,x1,x2,tempx1,tempx2;
    private volatile boolean finished = false;
    Thread t;
    JPanel jpnl;
    
    
    public SwapBubbleNodes(JButton btn1, JButton btn2, BubbleSort bs,JPanel jp){
        y=btn1.getY();
        x1=btn1.getX();
        x2=btn2.getX();
        tempx1 = x1;
        tempx2 = x2;
        this.buttonLeft=btn1;
        this.buttonRigt=btn2;
        this.bs=bs;
        this.jpnl = jp;
    }
    
    public void start(){
        if(t==null){
            t = new Thread(this);
            t.start();
        }
    }
    
    public void run(){
           swapTimer.start();

    }
    
    private void Swap(){
       if(tempx1<=x2){
           buttonRigt.setBackground(Color.blue);
           buttonLeft.setBackground(Color.blue);
           buttonLeft.setLocation(tempx1,y);
           buttonRigt.setLocation(tempx2,y);
           jpnl.repaint();
           swapTimer.start();
       }
       else{
           jpnl.repaint();
           swapTimer.stop();
           buttonRigt.setBackground(Color.white);
           buttonLeft.setBackground(Color.white);
      
           if(bs!=null){
               synchronized(bs){
               try {
                   bs.notify();
               } catch (Exception e) {
               }
            }    
           }

       }
   } 
   

   

   
    Timer swapTimer = new Timer(SessionHandler.getCurrentSortingSpeed(),new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

            Swap();
            tempx1++;
            tempx2--;
            
            
        }
    });
}