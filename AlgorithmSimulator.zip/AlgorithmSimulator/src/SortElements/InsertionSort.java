/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SortElements;

import RootElement.SessionHandler;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

/**
 *
 * @author Ishan
 */
public class InsertionSort implements Runnable{
    int [] intArray;
    JButton [] btnArray;
    Thread t;
    JPanel jp;
    volatile boolean finished = false;
    JTextField jtf;
    JTextField jtf2;
    JButton sortbtn;
    public  InsertionSort(int [] arr, JButton [] btn, JPanel jp, JTextField txt,JTextField txt2,JButton sbtn){
        this.btnArray=btn;
        this.intArray=arr;
        this.jp = jp;
        this.jtf=txt;
        this.jtf2=txt2;
        this.sortbtn=sbtn;
        finished = false;
    }
    
    public void start(){
        if(t==null){
            t = new Thread(this);
            t.start();
        }
    }
    
    public void stopThread(){
        finished=true;
    }
    
    public void run(){
        sortbtn.setEnabled(finished);
        
        while(!finished){
            
            int temp;
            JButton tempBtn=null;
            int key=0;
            
            for(int i=1; i<intArray.length; i++){
               key = intArray[i];
               jtf.setText(String.valueOf(key));
               jtf2.setText(String.valueOf(i+1));
               synchronized(t){
                   slowTimer.start();
                   try {
      
                       t.wait();
                       
                   } catch (Exception e) {
                   }
               }
                for(int j=i;j>0;j--){
                    if(intArray[j]<intArray[j-1]){
                    btnArray[j].setBackground(Color.blue);    
                    temp=intArray[j];
                    intArray[j]=intArray[j-1];
                    intArray[j-1]=temp;
                    
                    SwapNodes sw = new SwapNodes(btnArray[j-1], btnArray[j],this,jp);
                    synchronized(this){
                        sw.start();
                        try {
                            System.out.println("waiting...");
                            this.wait();
                            
                        } 
                        
                        catch (Exception e) {
                        }
                        System.out.println("Main thread is back");
                        tempBtn = btnArray[j-1];
                        btnArray[j-1]=btnArray[j];
                        btnArray[j]=tempBtn;
                        
                    }
                }
                btnArray[j-1].setBackground(Color.red);  
                btnArray[j].setBackground(Color.red);
            }
        }
        for(int k=0; k<btnArray.length; k++){
            btnArray[k].setBackground(Color.red);
            }
        finished = true;
        sortbtn.setEnabled(finished);
        }
        System.out.println("Thread Stopped");

    }
    
    
    Timer slowTimer = new Timer(2000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            synchronized(t){
                t.notify();
            }
        }
    });

}







class SwapNodes implements Runnable{
    private InsertionSort is=null;
    JButton buttonLeft, buttonRigt;
    int y,x1,x2,tempx1,tempx2;
    Thread t;

    JPanel jpnl;

    public SwapNodes(JButton btn1, JButton btn2, InsertionSort is,JPanel jp){
        y=btn1.getY();
        x1=btn1.getX();
        x2=btn2.getX();
        tempx1 = x1;
        tempx2 = x2;
        this.buttonLeft=btn1;
        this.buttonRigt=btn2;
        this.is = is;
        this.jpnl = jp;
 
    }

    public void start(){
        if(t==null){
            t = new Thread(this);
            t.start();
        }
    }
    public void run(){

        swapTimer.start();

    }

   public void Swap(){
       if(tempx1<=x2){
           buttonLeft.setLocation(tempx1,y);
           buttonRigt.setLocation(tempx2,y);
           jpnl.repaint();
           swapTimer.start();
       }
       else{
           jpnl.repaint();
           swapTimer.stop();
           buttonRigt.setBackground(Color.red);
           
           if(is!=null){
               synchronized(is){
               try {
                   is.notify();
               } catch (Exception e) {
               }
           }
           }
       }
   } 
   

   

   
    Timer swapTimer = new Timer(SessionHandler.getCurrentSortingSpeed(),new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

            Swap();
            tempx1++;
            tempx2--;
            
            
        }
    });


}