/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RootElement;

import javax.swing.JButton;

/**
 *
 * @author Ishan
 */
public class SessionHandler {
    private static int[] initialArr = new int[8];
    private static  JButton[] btnArr = new JButton[8];
    private static String sortingMethod="";
    private static int currentSortingSpeed=20;
    private static String currentStatus="pending";

    public static String getCurrentStatus() {
        return currentStatus;
    }

    public static void setCurrentStatus(String currentStatus) {
        SessionHandler.currentStatus = currentStatus;
    }

    public static int getCurrentSortingSpeed() {
        return currentSortingSpeed;
    }

    public static void setCurrentSortingSpeed(int currentSortingSpeed) {
        SessionHandler.currentSortingSpeed = currentSortingSpeed;
    }
    
    public static String getSortingMethod() {
        return sortingMethod;
    }

    public static void setSortingMethod(String sortingMethod) {
        SessionHandler.sortingMethod = sortingMethod;
    }
    
    
    public static int[] getInitialArray() {
        return initialArr;
    }

    public static void setInitialArray(int[] Arr) {
        initialArr = Arr;
    }
    
    public static void setButtonArray(JButton arr[]){
        SessionHandler.btnArr=arr;
    }
    public static void setValuestoButtons(){
        for(int i=0;i<=7;i++){
            btnArr[i].setText(String.valueOf(initialArr[i]));
        }
    }
}
