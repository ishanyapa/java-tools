/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scanner;

import java.net.InetAddress;
import javax.swing.JButton;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;

/**
 *
 * @author Ishan
 */
public class Scanner implements Runnable{
    
    Thread t = null;
    boolean scanStatus = false;
    JTextArea txtarea;
    JProgressBar jprb;
    int threadId;
    int prevId=0;
    int [] digit;
    byte[] ipaddr;
    int number;
    JButton jbtn;
    public Scanner(int tid,JTextArea txta,JProgressBar jpb,int []a, JButton b){
        this.threadId = tid;
        this.prevId = tid-51;
        this.txtarea=txta;
        this.jprb=jpb;
        this.number = a[0];
        this.jbtn=b;
    }
    public Scanner(JTextArea txta,JProgressBar jpb, int[] a,JButton b){
        this.txtarea=txta;
        this.jprb=jpb;
        this.digit=a;
        this.jbtn=b;
    }
    
    public void initialize(){
        txtarea.append("Scan started !\n");
        for(int i=51;i<=255;i+=51){
            Scanner sc = new Scanner(i,txtarea,jprb,digit,jbtn);
            sc.start();
            System.out.println("Thread "+i+" created");
        }
    }
    
    public void start(){
        if(t==null){
            t = new Thread(this);
            t.start();
            scanStatus=true;
        }
    }
    
    
    public void kill(){
        
    }
    public void run(){
        
        
        while(scanStatus){
            
            for(int i=prevId;i<=threadId;i++){
                UpdateBar();
                try {
                    ipaddr = new byte[] {(byte)192,(byte)168,(byte)number,(byte)i};
                    
                    InetAddress inet = InetAddress.getByAddress(ipaddr);
                    
                    boolean status = inet.isReachable(5000);
                    if(status){
                        txtarea.append(inet.getHostAddress() + " is reachable\n");
                        
                    }
                    
                    if(i==threadId){
                        scanStatus=false;
                        System.out.println("Thread "+threadId+" stopped");
                        if(threadId==255){
                            UpdateBar(255);
                            txtarea.append("Scan Completed !");
                            jbtn.setText("Scan your LAN");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
               
                
            }
        }
    }
    
    private synchronized void UpdateBar(){

        jprb.setValue(jprb.getValue()+1);
        
    }
    
    private synchronized void UpdateBar(int val){
        jprb.setValue(val);
    }
}
